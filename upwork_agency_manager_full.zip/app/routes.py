from flask import Blueprint, request, jsonify
from .models import db, Job, Proposal, Task, TaskComment
from datetime import datetime

routes = Blueprint('routes', __name__)

@routes.route('/jobs', methods=['POST'])
def create_job():
    data = request.json
    job = Job(
        job_id=data['job_id'],
        title=data['title'],
        description=data['description'],
        connects_required=data['connects_required'],
        category=data['category'],
        skills_requested=data['skills_requested'],
        date_posted=datetime.strptime(data['date_posted'], '%Y-%m-%d'),
        deadline=datetime.strptime(data['deadline'], '%Y-%m-%d'),
        stage='open',
        expected_cost=data['expected_cost'],
        expected_earning=data['expected_earning'],
        client_rating=data['client_rating'],
        feasibility_score=data['feasibility_score'],
        link=data['link']
    )
    db.session.add(job)
    db.session.commit()
    return jsonify({"message": "Job created successfully"})

@routes.route('/proposals', methods=['POST'])
def create_proposal():
    data = request.json
    proposal = Proposal(
        owner_email=data['owner_email'],
        job_id=data['job_id'],
        date=datetime.strptime(data['date'], '%Y-%m-%d')
    )
    db.session.add(proposal)
    db.session.commit()
    return jsonify({"message": "Proposal created successfully"})

@routes.route('/tasks', methods=['POST'])
def create_task():
    data = request.json
    task = Task(
        owner_email=data['owner_email'],
        job_id=data['job_id'],
        assigned_to_email=data['assigned_to_email'],
        created_datetime=datetime.strptime(data['created_datetime'], '%Y-%m-%d %H:%M:%S'),
        deadline_datetime=datetime.strptime(data['deadline_datetime'], '%Y-%m-%d %H:%M:%S'),
        priority=data['priority'],
        description=data['description'],
        status='To Do'
    )
    db.session.add(task)
    db.session.commit()
    return jsonify({"message": "Task created successfully"})

@routes.route('/tasks/status', methods=['PATCH'])
def update_task_status():
    data = request.json
    task = Task.query.filter_by(
        owner_email=data['owner_email'],
        job_id=data['job_id'],
        created_datetime=datetime.strptime(data['created_datetime'], '%Y-%m-%d %H:%M:%S')
    ).first()
    if not task:
        return jsonify({"error": "Task not found"}), 404

    task.status = data['status']
    if data['status'] == 'Completed':
        task.completed_datetime = datetime.now()

    db.session.commit()
    return jsonify({"message": "Task status updated"})

@routes.route('/tasks/comment', methods=['POST'])
def add_comment():
    data = request.json
    comment = TaskComment(
        owner_email=data['owner_email'],
        job_id=data['job_id'],
        created_datetime=datetime.strptime(data['created_datetime'], '%Y-%m-%d %H:%M:%S'),
        commenter_email=data['commenter_email'],
        comment_text=data['comment_text'],
        created_at=datetime.now()
    )
    db.session.add(comment)
    db.session.commit()
    return jsonify({"message": "Comment added successfully"})