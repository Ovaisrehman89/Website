from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = 'user'
    email = db.Column(db.String(255), primary_key=True)
    first_name = db.Column(db.String(100))
    last_name = db.Column(db.String(100))
    contact = db.Column(db.String(20))
    upwork_profile = db.Column(db.Text)
    connects_balance = db.Column(db.Integer)
    title = db.Column(db.String(255))
    hourly_rate = db.Column(db.Numeric(10, 2))
    milestone_rate = db.Column(db.Numeric(10, 2))

class SkillsDirectory(db.Model):
    __tablename__ = 'skills_directory'
    skill_version = db.Column(db.String(100), primary_key=True)
    category = db.Column(db.String(100))
    sub_category = db.Column(db.String(100))

class UserSkills(db.Model):
    __tablename__ = 'user_skills'
    email = db.Column(db.String(255), db.ForeignKey('user.email'), primary_key=True)
    skill_version = db.Column(db.String(100), db.ForeignKey('skills_directory.skill_version'), primary_key=True)
    proficiency = db.Column(db.String(50))

class Relationship(db.Model):
    __tablename__ = 'relationships'
    user_email = db.Column(db.String(255), db.ForeignKey('user.email'), primary_key=True)
    manager_email = db.Column(db.String(255), db.ForeignKey('user.email'), primary_key=True)
    role = db.Column(db.String(50))
    status = db.Column(db.String(50))

class Job(db.Model):
    __tablename__ = 'jobs'
    job_id = db.Column(db.String(100), primary_key=True)
    title = db.Column(db.String(255))
    description = db.Column(db.Text)
    connects_required = db.Column(db.Integer)
    category = db.Column(db.String(100))
    skills_requested = db.Column(db.Text)
    date_posted = db.Column(db.Date)
    deadline = db.Column(db.Date)
    stage = db.Column(db.String(100))
    expected_cost = db.Column(db.Numeric(10, 2))
    expected_earning = db.Column(db.Numeric(10, 2))
    client_rating = db.Column(db.Numeric(3, 2))
    feasibility_score = db.Column(db.Numeric(4, 2))
    link = db.Column(db.String(255))

class Proposal(db.Model):
    __tablename__ = 'proposal'
    owner_email = db.Column(db.String(255), db.ForeignKey('user.email'), primary_key=True)
    job_id = db.Column(db.String(100), db.ForeignKey('jobs.job_id'), primary_key=True)
    date = db.Column(db.Date)

class Project(db.Model):
    __tablename__ = 'project'
    owner_email = db.Column(db.String(255), db.ForeignKey('proposal.owner_email'), primary_key=True)
    job_id = db.Column(db.String(100), db.ForeignKey('proposal.job_id'), primary_key=True)
    title = db.Column(db.String(255))
    description = db.Column(db.Text)
    created_at = db.Column(db.Date)

class Task(db.Model):
    __tablename__ = 'tasks'
    owner_email = db.Column(db.String(255), db.ForeignKey('project.owner_email'), primary_key=True)
    job_id = db.Column(db.String(100), db.ForeignKey('project.job_id'), primary_key=True)
    created_datetime = db.Column(db.DateTime, primary_key=True)
    assigned_to_email = db.Column(db.String(255), db.ForeignKey('user.email'))
    deadline_datetime = db.Column(db.DateTime)
    completed_datetime = db.Column(db.DateTime)
    priority = db.Column(db.String(50))
    description = db.Column(db.Text)
    status = db.Column(db.String(50), default='To Do')

class TaskComment(db.Model):
    __tablename__ = 'task_comments'
    comment_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    owner_email = db.Column(db.String(255))
    job_id = db.Column(db.String(100))
    created_datetime = db.Column(db.DateTime)
    commenter_email = db.Column(db.String(255), db.ForeignKey('user.email'))
    comment_text = db.Column(db.Text)
    created_at = db.Column(db.DateTime)